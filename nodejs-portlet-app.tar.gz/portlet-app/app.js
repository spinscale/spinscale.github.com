
/**
 * Module dependencies.
 */

var express = require('express'),
    connect = require('connect'),
    MemoryStore = require('connect/middleware/session/memory'),
    Persistence = require('./MongoDB');

var app = module.exports = express.createServer();

var minute = 60 * 1000
var memory = new MemoryStore({ reapInterval: minute, maxAge: minute * 5 });

var User = Persistence.User
var Widget = Persistence.Widget

// Configuration

app.configure(function(){
    app.set('views', __dirname + '/views');
    
    app.use(connect.logger({ format : ":method :url"}));
    app.use(connect.bodyDecoder());
    app.use(connect.cookieDecoder());
    app.use(connect.session({ store: memory, secret: 'foobar' }))
    app.use(connect.methodOverride());
    app.use(connect.compiler({ src: __dirname + '/public', enable: ['less'] }));
    app.use(app.router);
    app.use(connect.staticProvider(__dirname + '/public'));
    // session management
    //app.use(express.session());
    //app.use(connect.session({ store: new MemoryStore({reapInterval: -1 }) }))
});

app.configure('development', function(){
    app.use(connect.errorHandler({ dumpExceptions: true, showStack: true })); 
});

app.configure('production', function(){
   app.use(connect.errorHandler()); 
});

// Some helper functions
function findWidgetById(id, widgetCollection) {
	for (var i = 0 ; i < widgetCollection.length; i++) {
		var widget = widgetCollection[i]
		if (widget.id == id) {
			return widget;
		}
	}
}



// Routes

app.get('/', function(req, res){
    res.render('index.jade', {
        locals: {
            title: 'Login for portal'
        }
    });
});



app.post('/login', function(req, res){
	var user = req.param("user")
	var pass = req.param("pass")

	User.find({"user" : user, "pass" : pass}).first(function(userObj) {
		if (userObj != null && userObj.user != null) {
			req.session.name = userObj.user
			res.redirect("/portal")
		} else {
			res.redirect("/")
		}

	})
});



app.get('/logout', function(req, res){
	req.session.destroy(function(err) {
	   res.redirect("/")
	})
});



app.get('/portal', function(req, res){
    if (req.session.name == undefined) {
        res.redirect("/")
    } else {
    	User.find({ user : req.session.name }).first(function(user) {
		Widget.find({ id : { '$in' : user.widgets }}).all(function(widgets){

			// TODO: This is bad, but $in does not return sorted by the user.widgets sort, so I used this quickhack
			var sortedWidgets = new Array();
			for (var pos = 0 ; pos < user.widgets.length ; pos++) {
				var widgetId = user.widgets[pos]
				var widget = findWidgetById(widgetId, widgets)
				sortedWidgets[pos] = widget
			}

			res.render('portal.jade', {
		            locals: {
                		title: 'Portal',
				user : user,
				widgets : sortedWidgets // instead of widgets
		            }
		        });
		})
	})
    }
});



app.post('/config', function(req, res) {
	if (req.session.name == undefined) {
		res.redirect('/')
	} else {
    		User.find({ user : req.session.name }).first(function(user) {
			user.widgets = req.param("ids").split(',')
			user.save(function() {
				res.send({result : "success" })
			})
		})
	}
})

// Only listen on $ node app.js
if (!module.parent) app.listen(3000);
