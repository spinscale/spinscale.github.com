require.paths.unshift('/home/alex/Downloads/LearnBoost-mongoose-48dca61');
var mongoose = require('mongoose').Mongoose;

mongoose.model('User', {
    properties: ['user', 'pass', 'widgets' ],
    indexes: [ { 'user' : 1 } , { unique : true }  ],
});

mongoose.model('Widget', {
    properties: ['id', 'html', 'title' ],
    indexes: [ { 'id' : 1 } , { unique : true }  ],
});

var db = mongoose.connect('mongodb://localhost/nodeJS');

var User = exports.User  = db.model('User');
var Widget = exports.Widget = db.model('Widget');


// Helper function
function findOrCreateWidget(id) {	
	Widget.find({ "id": id }).one(function(queryResult){
		if (queryResult == null) {
			var w = new Widget();
			w.id = id;
			w.title = "The title of widget " + id
			w.html = '<div dojoType="dojox.widget.PortletSettings">Setup for ' + id + '</div><div>Drag me around by clicking on my title bar<br />This is the content of '+id+'</div>';
			w.save(function() {
				console.log("Saved Widget "+id)
			});
		} else {
			console.log("Widget "+ id + " already exists");
		}
	})
}



// Add a default user alr
User.find({ user: 'alr' }).all(function(array){
	if (array.length == 0) {
		var u = new User();
		u.user = 'alr';
		u.pass = 'test';
		u.widgets = [ "id1","id2","id3","id4" ]
		u.save(function() {
			console.log("Saved user alr");
		});
	} else {
		console.log("User alr already exists");
	}
});


// Add four default widgets
for (var i = 1 ; i < 5 ; i++) {
	findOrCreateWidget("id"+i)
}

